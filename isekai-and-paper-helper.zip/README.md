# install instructions

## wie fügt man die Erweiterung in chrome hinzu

- Öffne chrome://extensions/
- Klicke auf "Entpackte Erweiterung laden"
- Wähle den Ordner aus

## wie fügt man die Erweiterung in firefox hinzu

- Öffne about:debugging#/runtime/this-firefox
- Klicke auf "Temporäre Add-ons laden"
- Wähle die manifest.json-Datei aus

## how to add extension in chrome

- open chrome://extensions/
- click on load unpacked
- select the folder

## how to add extension in firefox

- open about:debugging#/runtime/this-firefox
- click on load temporary add-on
- select manifest.json file
